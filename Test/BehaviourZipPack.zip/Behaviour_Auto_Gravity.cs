﻿using UnityEngine;


namespace LazyPan {
    public class Behaviour_Auto_Gravity : Behaviour {
        private Transform bodyTran;
        private Vector2 velocity;
        private RectTransform rectBodyTran;
        public Behaviour_Auto_Gravity(Entity entity, string behaviourSign) : base(entity, behaviourSign) {
            bodyTran = Cond.Instance.Get<Transform>(entity, Label.BODY);
            rectBodyTran = bodyTran.GetComponent<RectTransform>();
            Game.instance.OnUpdateEvent.AddListener(OnGravityUpdate);
        }

        private void OnGravityUpdate() {
            if (rectBodyTran != null) {
                velocity.y += Time.deltaTime * 50f;
                Vector3 bodyTran = rectBodyTran.position;
                bodyTran -= (Vector3)velocity * Time.deltaTime;
                rectBodyTran.position = bodyTran;
            }
        }

        public override void DelayedExecute() {
            
        }

        public override void Clear() {
            base.Clear();
            Game.instance.OnUpdateEvent.RemoveListener(OnGravityUpdate);
        }
    }
}