﻿using UnityEngine.UI;

namespace LazyPan {
    public class Behaviour_Event_BeginUI : Behaviour {
        private Flow_Begin flow;

        public Behaviour_Event_BeginUI(Entity entity, string behaviourSign) : base(entity, behaviourSign) {
            Flo.Instance.GetFlow(out flow);
            Button startGameBtn = Cond.Instance.Get<Button>(flow.GetUI(), Label.Assemble(Label.START, Label.GAME));
            ButtonRegister.AddListener(startGameBtn, () => {
                flow.Next("Battle");
            });
        }

        public override void DelayedExecute() {
            
        }

        public override void Clear() {
            base.Clear();
        }
    }
}