﻿using UnityEngine;
using UnityEngine.InputSystem;

namespace LazyPan {
    public class Behaviour_Input_BirdFly : Behaviour {
        public Behaviour_Input_BirdFly(Entity entity, string behaviourSign) : base(entity, behaviourSign) {
            InputRegister.Instance.Load(InputRegister.LeftClick, InputClickEvent);
        }

        private void InputClickEvent(InputAction.CallbackContext obj) {
            if (obj.started) {
                Debug.Log("点击");
            }
        }

        public override void DelayedExecute() {
            
        }

        public override void Clear() {
            base.Clear();
            InputRegister.Instance.UnLoad(InputRegister.LeftClick, InputClickEvent);
        }
    }
}