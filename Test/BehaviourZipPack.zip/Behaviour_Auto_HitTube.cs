﻿using UnityEngine;


namespace LazyPan {
    public class Behaviour_Auto_HitTube : Behaviour {
        public Behaviour_Auto_HitTube(Entity entity, string behaviourSign) : base(entity, behaviourSign) {
            for (int i = 0; i < entity.Comp.Comps.Count; i++) {
                entity.Comp.Comps[i].Comp.OnTriggerEnterEvent2D.AddListener(OnTriggerEnter2D);
            }
        }

        private void OnTriggerEnter2D(Collider2D arg0) {
            Debug.Log(arg0.gameObject.name);
            MessageRegister.Instance.Dis(MessageCode.Settlement);
        }

        public override void DelayedExecute() {
            
        }

        public override void Clear() {
            base.Clear();
            for (int i = 0; i < entity.Comp.Comps.Count; i++) {
                entity.Comp.Comps[i].Comp.OnTriggerEnterEvent2D.RemoveListener(OnTriggerEnter2D);
            }
        }
    }
}